"use client";

import Link from "next/link";
import AnimatedGradient from "@/components/animated-gradient";
import { GradientWaveText } from "@/registry/spell-ui/gradient-wave-text";
import { PhoneMockup } from "@/components/landing/phone-mockup";
import { buttonVariants } from "@/components/ui/button";
import { cn } from "@/lib/utils";

export function LandingHero() {
  return (
    <section className="landing-hero">
      <AnimatedGradient style={{ zIndex: 0 }} config={{ preset: "Pulse" }} />
      <div className="landing-wrap relative z-10 grid items-center gap-10 py-16 lg:grid-cols-[1.05fr_0.95fr] lg:py-20">
        <div className="max-w-xl">
          <h1>
            <GradientWaveText
              align="left"
              bottomOffset={0}
              inView
              customColors={["#000000", "#1a1a1a", "#000000"]}
              className="h-auto text-[2.15rem] leading-[1.12] font-extrabold tracking-[-0.04em] sm:text-5xl [--gradient-wave-base:#000000]"
              ariaLabel="See what’s happening on campus"
            >
              See what’s happening on campus
            </GradientWaveText>
          </h1>
          <p className="mt-4 text-[16px] leading-relaxed text-[#33453d]">
            Rally is a live map of Texas Tech. Find what’s on, join in minutes, chat
            with the group, and earn points when you confirm you’re there.
          </p>
          <Link
            href="/app"
            className={cn(
              buttonVariants({ size: "lg" }),
              "mt-7 inline-flex h-12 rounded-xl bg-eucalyptus px-6 text-[15px] font-bold text-white hover:bg-eucalyptus/90",
            )}
          >
            Find your people
          </Link>
          <p className="mt-5 text-[13px] font-semibold text-eucalyptus">
            200K+ Downloads
            <span className="font-medium text-mute"> · students opening pins this week</span>
          </p>
        </div>
        <div className="relative flex min-h-[420px] items-center justify-center overflow-hidden rounded-[24px] border border-white/40 py-8 shadow-md">
          <PhoneMockup />
        </div>
      </div>
    </section>
  );
}
