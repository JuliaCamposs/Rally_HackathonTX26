import { RallyApp } from "@/components/rally-app";
import { getCurrentUserId } from "@/lib/current-user";
import { getUserPoints, listEvents } from "@/lib/queries";

export default async function CampusAppPage() {
  const currentUserId = await getCurrentUserId();
  const [initialData, initialPoints] = await Promise.all([
    listEvents({ time: "all", source: "all", categories: [] }, currentUserId),
    getUserPoints(currentUserId),
  ]);
  return <RallyApp initialData={initialData} initialPoints={initialPoints} />;
}
